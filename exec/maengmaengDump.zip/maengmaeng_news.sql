-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: j9d207.p.ssafy.io    Database: maengmaeng
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `news` (
  `news_id` int NOT NULL AUTO_INCREMENT,
  `news_type` varchar(45) DEFAULT NULL,
  `news_title` varchar(45) DEFAULT NULL,
  `news_image` varchar(150) DEFAULT NULL,
  `news_content` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`news_id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news`
--

LOCK TABLES `news` WRITE;
/*!40000 ALTER TABLE `news` DISABLE KEYS */;
INSERT INTO `news` VALUES (1,'Diamond','COVID-19 대유행','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/dia/DIA-1.png','COVID-19의 대유행으로 모든 극가의 물가와 부동산이 폭등하고, 화상 프로그램이 유행합니다.'),(2,'Diamond','미 연준 금리인상','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/dia/DIA-2.png','미 연방준비제도의 금리 인상으로 부동산 자산이 하락합니다.'),(3,'Diamond','우크라이나 전쟁','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/dia/DIA-3.png','우크라이나 전쟁으로 유가가 상승합니다. 기업 생산원가 상승으로 수출이 하락합니다.'),(4,'Diamond','석유파동','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/dia/DIA-4.png','아랍 지역의 산유국들이 대대적으로 석유 무기화 정책을 추진하여 저네계에 큰 파동이 일어납니다.'),(5,'Diamond','뉴욕 블랙아웃','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/dia/DIA-5.png','암흑으로 변한 도시에서 범죄가 난무합니다. 3억달러의 경제적 피해가 발생합니다.'),(6,'Diamond','아시아 외환위기','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/dia/DIA-6.png','미 달러화에 대한 태국의 밧 태환포기가 국제적인 금융 위기를 촉발 합니다.'),(7,'Diamond','WTO 설립','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/dia/DIA-7.png','세계 무역기구를 설립합니다.'),(8,'Diamond','서브프라임 모기지','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/dia/DIA-8.png','제2차 세계 대전 종전 이후 미국에 최악의 금융 위기(최대 규모 은행 파산)가 발생합니다.'),(9,'Diamond','갤럭시 S2 출시','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/dia/DIA-9.png','SAMSUNG에서 전설의 갤럭시 S2 제품을 출시합니다.'),(10,'Diamond','2002 월드컵 개최','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/dia/DIA-10.png','한국이 2002 월드컵에서 4강에 진출합니다.'),(11,'Diamond','9.11 테러','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/dia/DIA-11.png','이슬람 근본주의 세력 알카에다가 하이재킹 및 자살 테러를 일으킵니다.'),(12,'Diamond','아폴로 11호 달 착륙','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/dia/DIA-12.png','인류 최초로 달에 착륙합니다.'),(13,'Platinum','볼라 사이클론','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/platinum/PLE-1.png','가장 치명적인 사이클론이 발생해 방글라데시와 인도에서 최대 500,000명이 사망합니다.'),(14,'Platinum','베트남 전쟁 종료','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/platinum/PLE-2.png','분단국가이던 북베트남과 남베트남이 무력으로 통일됩니다.'),(15,'Platinum','삼춤백화점 붕괴','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/platinum/PLE-3.png','부실공사로 인해 삼풍백화점이 무너져 1,500명의 사상자가 발생하였습니다.'),(16,'Platinum','넬슨 만델라 대통령','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/platinum/PLE-4.png','남아프리카공화국 최초의 흑인 대통령 넬슨 만델라가 인종차별을 철폐하고 노벨 평화상을 받습니다.'),(17,'Platinum','천안함 피격','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/platinum/PLE-5.png','천안함이 초계임무 수행 도중 북한 해군 잠수정의 어뢰에 공격당해 선체가 반파되며 침몰되었습니다.'),(18,'Platinum','BTS 데뷔','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/platinum/PLE-6.png','한국의 전설의 보이그룹 BTS가 데뷔하였습니다.'),(19,'Platinum','동일본 대지진','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/platinum/PLE-7.png','일본 역사상 최대 규모의 지진이 발생해 후쿠시마 원자력 발전소가 폭발하였습니다.'),(20,'Platinum','YOUTUBE 창립','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/platinum/PLE-8.png','온라인 동영상 공유 플랫폼 YOUTUBE를 창립합니다.'),(21,'Platinum','알파고 vs 이세돌','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/platinum/PLE-9.png','구글 딥마인드 챌리지 매치에서 알파고가 이세돌 9단을 이겼습니다.'),(22,'Platinum','일본 수출 규제','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/platinum/PLE-10.png','일본이 한국을 대상으로 수출 규제를 시행합니다.'),(23,'Platinum','수에즈 운하 사고','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/platinum/PLE-11.png','에버기븐호로 인해 수에즈 운하가 막혀 전세계적으로 무역 이슈가 발생합니다.'),(24,'Platinum','평창 올림픽 개최','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/platinum/PLE-12.png','한국의 평창에서 동계 올림픽을 개최합니다. 한국에 대한 관심도가 상승합니다.'),(25,'Platinum','COVID-19 백신 개발','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/platinum/PLE-13.png','COVID-19의 백신이 개발되었습니다.'),(26,'Platinum','일본 방사능 오염수 방류','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/platinum/PLE-14.png','일본이 원전에서 발생한 방사능 오염수를 해양에 방류했습니다.'),(27,'Platinum','킹파드 국제공항 건설 추진','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/platinum/PLE-15.png','사우디아라비아에 세계 최대 규모의 공항을 건설하겠다고 발표했습니다.'),(28,'Bronze','ARPANET 상용화','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/bronze/BRO-1.png','인터넷의 초기 형태인 ARPANET이 상용화 되었습니다.'),(29,'Bronze','샤넬 N.19 런칭','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/bronze/BRO-2.png','샤넬의 대표 향수인 N.19가 런칭되었습니다.'),(30,'Bronze','세계 무역 센터 폭탄 테러','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/bronze/BRO-3.png','미국에 위치한 세계 무역 센터에서 폭탄테러가 발생했습니다.'),(31,'Bronze','영국 푸켓블루 대유행','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/bronze/BRO-4.png','영국에서 감기 바이러스 푸켓 블루가 대유행 합니다.'),(32,'Bronze','개인용 컴퓨터의 개발 및 보급','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/bronze/BRO-5.png','IBM에서 개인에게 PC 보급이 시작되었습니다.'),(33,'Bronze','피라미드 발견','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/bronze/BRO-6.png','이집트에서 138기의 피라미드가 발견되었습니다.'),(34,'Bronze','GMO 식품 유해성 밝혀져','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/bronze/BRO-7.png','프랑스에서 GMO 식품의 유해성을 밝혀냈습니다.'),(35,'Bronze','베이징 올림픽 개최','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/bronze/BRO-8.png','중국에서 베이징 올림픽을 개최하여 관광객들이 몰렸습니다.'),(36,'Bronze','자동차용 디스플레이 성장','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/bronze/BRO-9.png','자동차에 들어 가는 디스플레이로 인해 성장세를 보입니다.'),(37,'Bronze','유로 사용 시작','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/bronze/BRO-10.png','유럽 연합 국가들이 유로를 사용하기 시작했습니다.'),(38,'Bronze','비트코인 출시','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/bronze/BRO-11.png','비트코인의 출현으로 정보 통신 분야의 관심도가 증가했습니다.'),(39,'Bronze','아이폰 발매','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/bronze/BRO-12.png','애플에서 혁신적인 스마트폰인 아이폰이 출시 되었습니다.'),(40,'Bronze','남아공 월드컵','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/bronze/BRO-13.png','남아프리카공화국에서 개최된 월드컵으로 관광객들이 몰렸습니다.'),(41,'Bronze','애그플레이션','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/bronze/BRO-14.png','에그플레이션으로 인해 농산물의 가격이 상승했습니다.'),(42,'Bronze','‘Gang-Bonde’ 상용화','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/bronze/BRO-15.png','한국에서 반도체 생산성을 100배 올릴수 있는 Gang-Bonder(갱 본더)’ 장비를 개발했다'),(43,'Bronze','구제역 발생','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/bronze/BRO-16.png','구제역이 발생해서 축산업에 피해가 예상됩니다.'),(44,'Bronze','불 붙은 화성 레이스','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/bronze/BRO-17.png','우주강국들이 화성레이스에 관심을 보입니다.'),(45,'Bronze','북한 미사일 도발','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/bronze/BRO-18.png','북한의 미사일 도발로 인해 국민들이 두려움에 떨고 있습니다.'),(46,'Bronze','카타르 윌드컵','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/bronze/BRO-19.png','카타르에서 개최된 월드컵으로 관광객들이 몰렸습니다.'),(47,'Bronze','시리아 내전','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/bronze/BRO-20.png','시리아에서 발생한 내전으로 인해 중동 국가들이 피해를 입고 있습니다.'),(48,'Bronze','블랙핑크 지수, 파리 패션쇼를 빛낸 눈부신 미모','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/bronze/BRO-21.png','블랙핑크 지수가 미모로 패션쇼를 빛냈습니다.'),(49,'Bronze','원자재 가격 상승','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/bronze/BRO-22.png','원자재 가격 상승으로 인해 제조 분야가 타격을 입었습니다.'),(50,'Bronze','자율주행 사고','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/bronze/BRO-23.png','자율주행 차량에 치여 사망하는 사건이 발생했습니다.'),(51,'Bronze','벨벳 비폭력 혁명','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/bronze/BRO-24.png','수십만의 체코 시민들이 열쇠를 흘들며 사회주의의 종말을 고헸습니다.'),(52,'Bronze','톰브라운 브랜드 이미지 손상','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/bronze/BRO-25.png','톰브라운 가디건이 양아치들의 공식패션으로 낙인찍혔습니다.'),(53,'Bronze','의약품 리베이트','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/bronze/BRO-26.png','의약품 리베이트로 인해 약값이 인상하여 정부에서 제재가 들어갔습니다.'),(54,'Bronze','소마 탄광 폭발 사고','https://maeng.s3.ap-northeast-2.amazonaws.com/images/newscard/bronze/BRO-27.png','튀르키예 소마의 탄광 지하에서 폭발이 일어났습니다.');
/*!40000 ALTER TABLE `news` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-06  9:40:53
