-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: j9d207.p.ssafy.io    Database: maengmaeng
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `avatar`
--

DROP TABLE IF EXISTS `avatar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `avatar` (
  `avatar_id` int NOT NULL AUTO_INCREMENT,
  `avatar_name` varchar(45) DEFAULT NULL,
  `avatar_image_bg` varchar(200) DEFAULT NULL,
  `avatar_image_no_bg` varchar(200) DEFAULT NULL,
  `avatar_price` int DEFAULT NULL,
  PRIMARY KEY (`avatar_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avatar`
--

LOCK TABLES `avatar` WRITE;
/*!40000 ALTER TABLE `avatar` DISABLE KEYS */;
INSERT INTO `avatar` VALUES (1,'마루쉐','https://maeng.s3.ap-northeast-2.amazonaws.com/images/character/character-dog.png','https://maeng.s3.ap-northeast-2.amazonaws.com/images/character/character-dog-nobg.png',450),(2,'맹티즈','https://maeng.s3.ap-northeast-2.amazonaws.com/images/character/character-dog2.png','https://maeng.s3.ap-northeast-2.amazonaws.com/images/character/character-dog2-nobg.png',450),(3,'깜찍이','https://maeng.s3.ap-northeast-2.amazonaws.com/images/character/character-rabbit.png','https://maeng.s3.ap-northeast-2.amazonaws.com/images/character/character-rabbit-nobg.png',1250),(4,'도치','https://maeng.s3.ap-northeast-2.amazonaws.com/images/character/character-hedgehog.png','https://maeng.s3.ap-northeast-2.amazonaws.com/images/character/character-hedgehog-nobg.png',1250),(5,'푸바오','https://maeng.s3.ap-northeast-2.amazonaws.com/images/character/character-panda.png','https://maeng.s3.ap-northeast-2.amazonaws.com/images/character/character-panda-nobg.png',4800),(6,'고래찡','https://maeng.s3.ap-northeast-2.amazonaws.com/images/character/character-whale.png','https://maeng.s3.ap-northeast-2.amazonaws.com/images/character/character-whale-nobg.png',4800),(7,'불닭','https://maeng.s3.ap-northeast-2.amazonaws.com/images/character/character-phoenix.png','https://maeng.s3.ap-northeast-2.amazonaws.com/images/character/character-phoenix-nobg.png',6300),(8,'김철수','https://maeng.s3.ap-northeast-2.amazonaws.com/images/character/character-squirrel.png','https://maeng.s3.ap-northeast-2.amazonaws.com/images/character/character-squirrel-nobg.png',3150),(9,'코니','https://maeng.s3.ap-northeast-2.amazonaws.com/images/character/character-unicorn.png','https://maeng.s3.ap-northeast-2.amazonaws.com/images/character/character-unicorn-nobg.png',6300);
/*!40000 ALTER TABLE `avatar` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-06  9:40:55
