-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: j9d207.p.ssafy.io    Database: maengmaeng
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `news_stock`
--

DROP TABLE IF EXISTS `news_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `news_stock` (
  `news_stock_id` int NOT NULL AUTO_INCREMENT,
  `news_id` int NOT NULL,
  `stock_id` int NOT NULL,
  `effect` int DEFAULT NULL,
  PRIMARY KEY (`news_stock_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news_stock`
--

LOCK TABLES `news_stock` WRITE;
/*!40000 ALTER TABLE `news_stock` DISABLE KEYS */;
INSERT INTO `news_stock` VALUES (1,1,2,200),(2,1,5,-60),(3,1,11,-60),(4,1,14,-60),(5,3,1,30),(6,3,6,-20),(7,3,11,-20),(8,3,14,-20),(9,9,2,-30),(10,12,11,80),(11,20,2,40),(12,21,2,40),(13,25,10,40),(14,26,13,-30),(15,27,3,40),(16,29,9,20),(17,34,7,-20),(18,36,2,20),(19,36,6,10),(20,38,2,20),(21,39,2,10),(22,39,4,10),(23,41,7,20),(24,42,4,15),(25,43,8,-20),(26,44,11,10),(27,48,9,10),(28,49,3,-10),(29,49,4,-10),(30,49,12,10),(31,49,14,-10),(32,50,6,-10),(33,52,9,-15),(34,53,10,-20),(35,54,12,-20);
/*!40000 ALTER TABLE `news_stock` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-06  9:40:52
