-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: j9d207.p.ssafy.io    Database: maengmaeng
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user_avatar`
--

DROP TABLE IF EXISTS `user_avatar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_avatar` (
  `user_avatar_id` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(45) NOT NULL,
  `avatar_id` int NOT NULL,
  `mounting` tinyint NOT NULL,
  PRIMARY KEY (`user_avatar_id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_avatar`
--

LOCK TABLES `user_avatar` WRITE;
/*!40000 ALTER TABLE `user_avatar` DISABLE KEYS */;
INSERT INTO `user_avatar` VALUES (1,'ksg2388',1,0),(2,'kws8697',1,0),(3,'dldlfgh2642',1,0),(4,'tkdrms2388',1,0),(5,'ksg2388',9,0),(6,'skrud5985',1,0),(7,'nwhjin',1,0),(8,'nwhjin',5,0),(9,'nwhjin',4,1),(10,'kws8697',7,0),(11,'kws8697',8,0),(12,'kws8697',3,0),(13,'skrud5985',8,0),(14,'nwhjin',6,0),(15,'nv_tkwjsrjatn6',1,1),(16,'kjg_0701',1,0),(17,'ksg2388',5,0),(18,'ksg2388',6,1),(19,'ksg2388',3,0),(20,'ksg2388',2,0),(21,'ksg2388',4,0),(22,'kjg_0701',9,0),(23,'ksg2388',7,0),(24,'kjg_0701',7,0),(25,'ksg2388',8,0),(26,'kjg_0701',6,0),(27,'kjg_0701',5,0),(28,'kjg_0701',8,0),(29,'kjg_0701',2,0),(30,'kjg_0701',3,1),(31,'kjg_0701',4,0),(32,'skrud5985',2,0),(33,'skrud5985',3,0),(34,'skrud5985',4,0),(35,'skrud5985',5,1),(36,'skrud5985',6,0),(37,'skrud5985',7,0),(38,'skrud5985',9,0),(39,'dldlfgh2642',5,0),(40,'dldlfgh2642',2,0),(41,'dldlfgh2642',3,0),(42,'dldlfgh2642',6,0),(43,'dldlfgh2642',7,0),(44,'dldlfgh2642',8,1),(45,'dldlfgh2642',4,0),(46,'dldlfgh2642',9,0),(47,'kws8697',2,1),(48,'kws8697',5,0),(49,'kws8697',9,0),(50,'tkdrms2388',6,1),(51,'nwhjin',8,0),(52,'kws8697',6,0),(53,'kws8697',4,0);
/*!40000 ALTER TABLE `user_avatar` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-06  9:40:55
